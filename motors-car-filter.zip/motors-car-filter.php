<?php
/*
Plugin Name: Motors Car Filter
Description: Un plugin per filtrare le auto disponibili per il noleggio.
Version: 1.0
Author: Il tuo nome
*/

// Funzione per visualizzare il modulo di filtro
function motors_car_filter() {
    ob_start(); ?>
    <form id="car-filter">
        <label for="marca">Marca:</label>
        <select id="marca" name="marca">
            <option value="">Seleziona una marca</option>
            <option value="ford">Ford</option>
            <option value="audi">Audi</option>
            <!-- Aggiungi altre opzioni qui -->
        </select>

        <label for="modello">Modello:</label>
        <select id="modello" name="modello">
            <option value="">Seleziona un modello</option>
            <option value="focus">Focus</option>
            <option value="a4">A4</option>
            <!-- Aggiungi altre opzioni qui -->
        </select>

        <label for="durata">Durata Noleggio (mesi):</label>
        <input type="number" id="durata" name="durata" min="1" max="36">

        <label for="km_inclusi">KM Inclusi:</label>
        <input type="number" id="km_inclusi" name="km_inclusi" min="0">

        <label for="canone_mensile">Canone Mensile (€):</label>
        <input type="number" id="canone_mensile" name="canone_mensile" min="0" step="0.01">

        <button type="submit">Cerca</button>
    </form>
    
    <div id="car-results"></div>

    <script>
        document.getElementById('car-filter').addEventListener('submit', function (e) {
            e.preventDefault();
            // Invia la richiesta AJAX
            const formData = new FormData(this);
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('car-results').innerHTML = data.html;
            });
        });
    </script>
    <?php
    return ob_get_clean();
}

// Registrare lo shortcode
add_shortcode('motors_car_filter', 'motors_car_filter');

// Funzione per gestire la richiesta AJAX
function motors_car_filter_ajax() {
    // Ricevi i dati, elabora e restituisci i risultati (da implementare)
    
    // Esempio dummy
    $html = '<h3>Risultati della ricerca</h3>';
    $html .= '<p>Mostra qui i risultati filtrati...</p>'; // Questo deve essere sostituito con logica di elaborazione reale

    wp_send_json_success(array('html' => $html));
}

add_action('wp_ajax_motors_filter', 'motors_car_filter_ajax');
add_action('wp_ajax_nopriv_motors_filter', 'motors_car_filter_ajax');
function motors_car_filter_ajax() {
    global $wpdb;
    
    // Recupera i parametri dalla richiesta AJAX
    $marca = isset($_POST['marca']) ? sanitize_text_field($_POST['marca']) : '';
    $modello = isset($_POST['modello']) ? sanitize_text_field($_POST['modello']) : '';
    $anno = isset($_POST['anno']) ? intval($_POST['anno']) : '';

    // Costruire la query per filtrare le auto
    $query = "SELECT * FROM wp_auto WHERE 1=1"; // Assicurati di utilizzare il tuo prefisso della tabella

    if (!empty($marca)) {
        $query .= $wpdb->prepare(" AND marca = %s", $marca);
    }
    if (!empty($modello)) {
        $query .= $wpdb->prepare(" AND modello = %s", $modello);
    }
    if (!empty($anno)) {
        $query .= $wpdb->prepare(" AND anno = %d", $anno);
    }

    // Esegui la query
    $auto = $wpdb->get_results($query);

    // Genera l'HTML per i risultati
    if ($auto) {
        foreach ($auto as $vettura) {
            echo '<div class="vettura">';
            echo '<h2>' . esc_html($vettura->marca) . ' ' . esc_html($vettura->modello) . '</h2>';
            echo '<p>Anno: ' . esc_html($vettura->anno) . '</p>';
            // Aggiungi altre informazioni relative alla vettura qui
            echo '</div>';
        }
    } else {
        echo '<p>No vehicles found.</p>'; // Messaggio per nessun risultato
    }

    // Termina il processo per evitare l'output superfluo
    wp_die();
}
function my_enqueue_scripts() {
    wp_enqueue_script('my-ajax-script', get_template_directory_uri() . '/js/my-ajax-script.js', array('jquery'), null, true);
    wp_localize_script('my-ajax-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'my_enqueue_scripts');
jQuery(document).ready(function($) {
    $('#filter-button').on('click', function() { // Assicurati di avere un bottone con l'ID corretto
        var marca = $('#marca').val();
        var modello = $('#modello').val();
        var anno = $('#anno').val();

        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: {
                action: 'motors_car_filter',
                marca: marca,
                modello: modello,
                anno: anno
            },
            success: function(response) {
                $('#results').html(response); // Assicurati di avere un contenitore per i risultati
            }
        });
    });
});
<input type="text" id="marca" placeholder="Marca">
<input type="text" id="modello" placeholder="Modello">
<input type="number" id="anno" placeholder="Anno">
<button id="filter-button">Filtra</button>
<div id="results"></div>
