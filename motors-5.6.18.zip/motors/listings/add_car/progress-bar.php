<div class="progress add-a-car-progress">
	<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="99" id="add-a-car-progress"></div>
</div>