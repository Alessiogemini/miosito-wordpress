<?php $id = stm_woo_shop_page_id(); ?>

<div class="stm-fullwidth-with-parallax-bg">
    <?php get_template_part('partials/rental/wizard-nav/main'); ?>
</div>